package model.contact;

public class ContactDAO {

}
