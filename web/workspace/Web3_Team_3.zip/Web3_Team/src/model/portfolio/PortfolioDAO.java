package model.portfolio;

public class PortfolioDAO {

}
